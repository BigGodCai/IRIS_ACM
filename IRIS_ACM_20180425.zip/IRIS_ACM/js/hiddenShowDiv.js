//function openNewSubRCPMISWindows(){
//	var subLevyno = document.getElementsByName("entity.levyno")[0].value;
//	var subEdiDate = document.getElementsByName("entity.ediDate")[0].value;
//	var url="rcpmis2101GoodsTradeFundAction!goToEditFromMain?subLevyno="+subLevyno+"&subEdiDate="+subEdiDate;
//	window.open(url, "","height=550,width=1000,top=0,left=0, toolbar=no, menubar=no, scrollbars=no, resizable=no,location=no, status=no")
//	return false;
//}
//
//function subEditOrView(){
//	var url="/IRIS_ACM/pages/rcpmis/RCPMIS2101IncomeEdit.jsp"; //目标页面
//	document.dataForm.action=url; 
//	var newwin = window.open('about:blank', 'newWindow', 'height=100,width=400,top=0,left=0, toolbar=no, menubar=no, scrollbars=no, resizable=no,location=no, status=no');
//	document.dataForm.target = 'newWindow';//这一句是关键
//	document.dataForm.submit();
//}

function showdiv(formid, targetName, levynoid, reportName, ajaxCallUrl,tableID) {
//	window.open ('/IRIS_ACM/pages/rcpmis/subRcpmis/RCPMIS2101GoodsTradeFundEdit.jsp', 
//			reportName, 'height=500, width=700, top=0, left=0, toolbar=no, menubar=no, scrollbars=no, resizable=no,location=n o, status=no');
//	return false;
	var targets = document.getElementsByName(targetName);
	var levynoTotal = document.getElementById("levyno").value;
	ajaxCallUrl = "RCPMISReportObjectAction";
	if (targets[0].style.display == "") {
		// 隐藏
		document.getElementById(levynoid).value = "";
		targets[0].style.display = "none";
	} else {
		// 显示
		targets[0].style.display = "";
		document.getElementById(levynoid).value = levynoTotal;
		// 查询
		$.ajax({
			cache : true,
			type : "POST",
			dataType : "json",
			url : ajaxCallUrl + "!selectForRCPMIS",
			data : {
				levyno : levynoTotal,
				reportName : reportName
			},
			async : false,
			error : function(request) {
				CxcDialog("提示框","Connection error","Error");
			},
			success : function(data) {
				var jsonObj = eval('(' + data + ')');
				var currentId;
				var dataTableElements = $('#'+tableID+' tr td');
				for (var i=0; i < dataTableElements.length -1; ++i){
					if ($(dataTableElements[i]).children().length > 0){
						if ($(dataTableElements[i]).children().first().attr("id") !== undefined){
							currentId=$(dataTableElements[i]).children().first().attr("id");
							if (typeof currentId !== typeof undefined && currentId !== false){
								$.each(jsonObj,function(name, value) {
									if(currentId == "entity_"+name){
										if(name == "ediDate" || name == "etlTimeStamp" 
											|| name == "customsdate"){
											$(dataTableElements[i]).children().first().val(formatDate(value));
										}else{
											$(dataTableElements[i]).children().first().val(value);
										}
									}
								});
							}
						}
					}
				}
			}
		});
	}

}
function   formatDate(now)   {    
    var test = new Date(parseInt(now));  
    var $_year = test.getFullYear();  
    var $_month = parseInt(test.getMonth())+1;  
    var $_day = test.getDate();  
    var $_f_date =  $_year +"-"+$_month+"-"+$_day  
    return   $_f_date;     
    }    

function getDate(tm){ 
	var tt=new Date(parseInt(tm) * 1000).toLocaleString().replace(/年|月/g, "-").replace(/日/g, " ") 
	return tt; 
	} 

function subRcpmisEditButton(formid, ajaxCallUrl, targetid, checkResult) {
	$.ajax({
		cache : true,
		type : "POST",
		url : ajaxCallUrl + "!subEdit",
		data : $('#' + formid + '').serialize(),// 你的formid
		beforeSend: function(){
			if(checkResult){
				return false;
			}
		},
		async : false,
		error : function(request) {
			CxcDialog("提示框","Connection error","Warning");
		},
		success : function(data) {
			/*var target = document.getElementById(targetid);
				target.style.display = "none";
				CxcDialog("提示框","添加成功!请确认主项信息并提交！","OK");*/
		}
	});

}

function checkOperType() {
	var objOne=document.getElementById("entity_opertype");
	var indexOne=objOne.selectedIndex;
	var valueOne=objOne.options[indexOne].value;
	
	if(valueOne=="2"){
		CxcDialog("提示框","必须填写修改／删除原因或申报无误理由","Warning");
		$("#actionDesc").addClass("required");
	}else if(valueOne=="3"){
		CxcDialog("提示框","必须填写修改／删除原因或申报无误理由","Warning");
		$("#actionDesc").addClass("required");
	}else{
		$("#actionDesc").removeClass();
	}
}

function beforeSubmit(){
	var objOne=document.getElementById("entity_opertype");
	var indexOne=objOne.selectedIndex;
	var valueOne=objOne.options[indexOne].value;
	var nameValue=window.document.getElementById("entity_actiondesc").value;  
	
	if(valueOne=="2"){
		$("#actionDesc").addClass("required");
		if (nameValue == "")   
        {  
			CxcDialog("提示框","必须填写修改／删除原因或申报无误理由","Warning");
            return false;  
        }  
	}else if(valueOne=="3"){
		$("#actionDesc").addClass("required");
		if (nameValue == "")   
        {  
			CxcDialog("提示框","必须填写修改／删除原因或申报无误理由","Warning");
            return false;  
        }  
	}else{
		$("#actionDesc").removeClass();
	}
    
    return true;  
	
}

function isApprovedEachDisAbleTrue(tableId){
	var isEditRecord = document.getElementsByName("isEditRecord");
	var isApproveds=document.getElementsByName("entity.isApproved");
	if((isApproveds!=undefined&&isApproveds[0]!=undefined&&isApproveds[0].value=="true")||
			(isEditRecord!=undefined&&isEditRecord[0]!=undefined&&isEditRecord[0].value=='2')){
		var dataTableElements = $('#'+tableId+' tr td');
		for (var i=0; i < dataTableElements.length -1; ++i){
			$(dataTableElements[i]).children(":first").removeAttr("disabled");
			$(dataTableElements[i]).children(":first").attr("disabled","disabled");
		}
	}
}

$(document).on('click','#approveOne',function(){
	var orgFormElements = $('#dataTable tr td');
	for (var i=0; i < orgFormElements.length -1; ++i){
		$(orgFormElements[i]).children(":first").removeAttr("disabled");
	}
});

$(document).on('click','#unApproveOne',function(){
	var orgFormElements = $('#dataTable tr td');
	for (var i=0; i < orgFormElements.length -1; ++i){
		$(orgFormElements[i]).children(":first").removeAttr("disabled");
	}
});