function selectAll() {
	var click = document.getElementById("AllApproved").checked;
	var arryObj = document.getElementsByName("approvedList");
	for (var i = 0; i < arryObj.length; i++) {
		if (typeof arryObj[i].type != "undefined" && arryObj[i].type == "checkbox") {
			if (click == true) {
						arryObj[i].checked = true;
			} 
			else {
				arryObj[i].checked = false;
			}
		}
	}
}

function checkSearchStartDateIsSelected() {
	$("#select").click(function() {
		var fag = true;
		var startDate = dojo.widget.byId("searchStartDate").inputNode.value;
		var endDate = dojo.widget.byId("searchEndDate").inputNode.value;

		if (endDate != "" && endDate != null) {
			if (startDate == "" || startDate == null) {
				CxcDialog("提示框","选择了结束日期,必须选择开始日期才可以做范围查询!","Warning");
				return false;
			}
		}
		return fag;
	});
}

