		$(document).on('click','#approveOne',function(){
			var orgFormElements = $('#dataTable tr td');
			for (var i=0; i < orgFormElements.length -1; ++i){
				$(orgFormElements[i]).children(":first").removeAttr("disabled");
			}
		});
		
		$(document).on('click','#unApproveOne',function(){
			var orgFormElements = $('#dataTable tr td');
			for (var i=0; i < orgFormElements.length -1; ++i){
				$(orgFormElements[i]).children(":first").removeAttr("disabled");
			}
		});