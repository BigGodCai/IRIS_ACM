function createRptnofromOppuserAndEdiDate(rptno,ediDate,cusType,actionName){
	var result=null;
	if(rptno==null||rptno==''||rptno=='-'){
		$.ajax({
			type:"post",
			async:false,
			url:actionName+"!createRptnoFromOppuserAndEdiDate.action",
			data:{ediDate:ediDate,cusType:cusType},
			success: function(msg){
				result=msg;
			}
		});
	}
	return result;
}

function createSerialNumber(exdebtcode,businessCode,dealNumber,reportCode,numberCode,ediDate,branchCode,actionName){
	var resultExdebtcode=null;
	if(resultExdebtcode==null||resultExdebtcode==''){
		$.ajax({
			type:"post",
			async:false,
			url:actionName+"!createSerialNumber.action",
			data:{ediDate:ediDate,dealNumber:dealNumber,businessCode:businessCode,branchCode:branchCode,reportCode:reportCode,numberCode:numberCode},
			success: function(msg){
				resultExdebtcode=msg;
			}
		});
	}
	return resultExdebtcode;
}

function removeLinkEntityExdebtcode(ediDate,dealNumber,businessCode,branchCode,linkEntityName,actionName){
	$.ajax({
		type:"post",
		async:false,
		url:actionName+"!removeLinkEntityExdebtcode.action",
		data:{ediDate:ediDate,dealNumber:dealNumber,businessCode:businessCode,branchCode:branchCode,entityName:linkEntityName},
	});
}