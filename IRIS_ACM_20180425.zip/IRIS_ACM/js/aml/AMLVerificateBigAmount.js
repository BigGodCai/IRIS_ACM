$(document).ready(function() {

	$("input[name='entity.CTID']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "CTID";
		
		var values = "CITP_"+ $("select[name='entity.CITP']").val() 
		+ "||" + "CTID_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.TBID']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "TBID";
		
		var values = "TBIT_"+ $("select[name='entity.TBIT']").val() 
		+ "||" + "TBID_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.TCID']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "TCID";
		
		var values = "TCIT_"+ $("select[name='entity.TCIT']").val() 
		+ "||" + "TCID_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.CTAC']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "CTAC";
		
		var values = "CTAC_"+ $("select[name='entity.CTAC']").val() 
		+ "||" + "CTAC_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.TCAC']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "TCAC";
		
		var values = "TCAT_"+ $("select[name='entity.TCAT']").val() 
		+ "||" + "TCAC_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.subBranchCode']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "subBranchCode";
		
		var values = "subBranchCode_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.FICT']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "FICT";
		
		var values = "FICT_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.RPDT']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "RPDT";
		
		var values = "HTDT_"+ $("select[name='entity.HTDT']").val() 
		+ "||" + "RPDT_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.CTNM']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "CTNM";
		
		var values = "CTNM_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.TBNM']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "TBNM";
		
		var values = "TBNM_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.FIRC']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "FIRC";
		
		var values = "FIRC_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.CRCD']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "CRCD";
		
		var values = "CRCD_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	$("input[name='entity.TRCD']").blur(function(){
		
		var urlValue = "amlVerificationAction";
		var fieldNameValue = "TRCD";
		
		var values = "CRCD_"+ $(this).val();
		
		var dataValues = {//设置数据源
				fieldName : fieldNameValue,
				sourceValues : values
			};
		
		callAjax(urlValue, dataValues);

	});
	
	

	function callAjax(urlValue,dataValues){
		$.ajax({
			type: "post",
			url: urlValue,
			data: dataValues,
			dataType:"json",//设置需要返回的数据类型
			success:callbackDisplayMessage,
			error:function(){
				alert("系统异常，请稍后重试！");
			}//这里不要加","
		});
	}	
	
	function callbackDisplayMessage(data){
	    if (data.length > 0) {
	    	var SELECTOR_ERRORS = $("#messageBox");
	        SELECTOR_ERRORS.empty();
	       
	        errors=data.split("||");
	        
	        for (var i = 0, errorLength = errors.length; i < errorLength; i++) {
	            SELECTOR_ERRORS.append(errors[i] + '<br />');
	        }
	        
	        SELECTOR_ERRORS.fadeIn(200);
	    } 
	    else {
	        SELECTOR_ERRORS.hide();
	    }
	}
});