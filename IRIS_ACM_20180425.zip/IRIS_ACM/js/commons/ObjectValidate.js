
function doObjectValidate(pageNameValue){
	var dataValues = {//设置数据源
		pageName : pageNameValue
	};
	
	$.ajax({
		type: "post",
		async: false,
        cache: false,
        timeout: 30000,			
		url: "objectValidationAction",
		data: dataValues,
		dataType:"json",//设置需要返回的数据类型
		success:callbackValidation,
		error:function(request, status, error){
	   	var SELECTOR_ERRORS = $("#messageBox");
			SELECTOR_ERRORS.empty();
			SELECTOR_ERRORS.append(request.responseText);
			SELECTOR_ERRORS.fadeIn(200);
		}//这里不要加","
	});	
}
			
function callbackValidation(data){
	var SELECTOR_ERRORS = $("#messageBox");
	SELECTOR_ERRORS.hide();
				
	var dataTableElements = $('#dataTable tr td');

	var objectValidations = getObjectValidations(data);
	var currentId;
	var validationResults = new Array();
	var oneAttributeValidationResults = new Array();
	var elementValue;
	for (var i=0; i < dataTableElements.length -1; ++i){
		if ($(dataTableElements[i]).children().length > 0 && $(dataTableElements[i]).children().first().is(":input")){
			if ($(dataTableElements[i]).children().first().attr("id") !== undefined){
				currentId = $(dataTableElements[i]).children().first().attr("id");
				if (typeof currentId !== typeof undefined && currentId !== false){
					for (var j in objectValidations){
						if (currentId === "entity_" + objectValidations[j].attributeName || currentId === objectValidations[j].attributeName){
							elementValue = $(dataTableElements[i]).children().first().val();				
							oneAttributeValidationResults = getValidateResult(elementValue, objectValidations[j], dataTableElements);
						}
						if (oneAttributeValidationResults.length > 0){
							$.merge(validationResults, oneAttributeValidationResults);
							oneAttributeValidationResults = [];
						}
					}
				}							
			}		
		}
	}
	var result = doCheckValidateResult(validationResults);
	if(result){
		removeDisable();
	}
	return result;
}

function doCheckValidateResult(validationResults){
	var SELECTOR_ERRORS = $("#messageBox");
	
	if (validationResults.length > 0){
		SELECTOR_ERRORS.empty();
        for (var i = 0, errorLength = validationResults.length; i < errorLength; i++) {
            SELECTOR_ERRORS.append(validationResults[i] + '<br />');
        }
        SELECTOR_ERRORS.fadeIn(200);
        
        return false;
	}
	else {
        SELECTOR_ERRORS.hide();

        setAllInputElementsEnable();
        
        return true;
    }		
}

function setAllInputElementsEnable(){
	$("#dataTable select:disabled").removeAttr("disabled");
}
			
function getValidateResult(elementValue, objectValidation, dataTableElements){
	var validationResults = new Array();
	var validateRoles = objectValidation.verificationRole.split("||");
	var oneResult;
	for (var i in validateRoles){
		if ("required" === validateRoles[i]){
			oneResult = validateRequired(elementValue, objectValidation);
		}
		else if (validateRoles[i].indexOf("maxLength") >= 0){ //maxLength[14]
			oneResult = validateMaxLength(elementValue, validateRoles[i], objectValidation);
		}	
		else if (validateRoles[i].indexOf("minLength") >= 0){ //minLength[14]
			oneResult = validateMinLength(elementValue, validateRoles[i], objectValidation);
		}		
		else if (validateRoles[i].indexOf("matches") >= 0){ //matches[A,B,C]
			oneResult = validateMatches(elementValue, validateRoles[i], objectValidation);
		}	
		else if (validateRoles[i].indexOf("matchValue") >= 0){ //matchValue[1,2,3]
			oneResult = validateMatchValue(elementValue, validateRoles[i], objectValidation);
		}	
		else if ("default" === validateRoles[i]){ //default
			oneResult = validateDefault(elementValue, objectValidation);
		}	
		else if ("validEmail" === validateRoles[i]){ //validEmail
			oneResult = validateValidEmail(elementValue, objectValidation);
		}	
		else if ("validEmails" === validateRoles[i]){ //validEmails
			oneResult = validateValidEmails(elementValue, objectValidation);
		}	
		else if ("validDate" === validateRoles[i]){ //validDate
			oneResult = validateValidDate(elementValue, objectValidation);
		}
		else if ("validDateOrBlank" === validateRoles[i]){ //validDate
			oneResult = validDateOrBlank(elementValue, objectValidation);
		}
		else if (validateRoles[i].indexOf("exactLength") >= 0){ //exactLength[15]
			oneResult = validateExactLength(elementValue, validateRoles[i], objectValidation);
		}		
		else if (validateRoles[i].indexOf("greaterThan") >= 0){ //greaterThan[15]
			oneResult = validateGreaterThan(elementValue, validateRoles[i], objectValidation);
		}	
		else if (validateRoles[i].indexOf("lessThan") >= 0){ //lessThan[15]
			oneResult = validateLessThan(elementValue, validateRoles[i], objectValidation);
		}
		else if ("alpha" === validateRoles[i]){ //alpha
			oneResult = validateAlpha(elementValue, objectValidation);
		}
		else if ("alphaOrBlank" === validateRoles[i]){ //alpha 必须为英文字符或为空
			oneResult = validateAlphaOrBlank(elementValue, objectValidation);
		}
		else if ("alphaNumeric" === validateRoles[i]){ //alphaNumeric 必须为英文字符与数字
			oneResult = validateAlphaNumeric(elementValue, objectValidation);
		}
		else if ("alphaNumericOrBlank" === validateRoles[i]){ //alphaNumeric 必须为英文字符与数字或为空
			oneResult = validateAlphaNumericOrBlank(elementValue, objectValidation);
		}
		else if ("alphaDash" === validateRoles[i]){ //alphaDash 英文字符,中划线或下划线
			oneResult = validateAlphaDash(elementValue, objectValidation);
		}
		else if ("alphaDashOrBlank" === validateRoles[i]){ //alphaDash 英文字符,中划线以及下划线或为空
			oneResult = validateAlphaDashOrBlank(elementValue, objectValidation);
		}
		else if ("numeric" === validateRoles[i]){ //numeric 必须为数字
			oneResult = validateNumeric(elementValue, objectValidation);
		}
		else if ("numericOrBlank" === validateRoles[i]){ //numeric 必须为数字或为空
			oneResult = validateNumericOrBlank(elementValue, objectValidation);
		}
		else if ("integer" === validateRoles[i]){ //integer 必须为整数
			oneResult = validateInteger(elementValue, objectValidation);
		}
		else if ("integerOrBlank" === validateRoles[i]){ //decimal 必须为整数或为空
			oneResult = validateIntegerOrBlank(elementValue, objectValidation);
		}
		else if ("decimal" === validateRoles[i]){ //decimal 必须为数值
			oneResult = validateDecimal(elementValue, objectValidation);
		}	
		else if ("decimalOrBlank" === validateRoles[i]){ //decimal 必须为数值或为空
			oneResult = validateDecimalOrBlank(elementValue, objectValidation);
		}	
		else if ("validAmount" === validateRoles[i]){  //validAmount 必须为正数金额
			oneResult = validAmount(elementValue, objectValidation);
		}
		else if ("validAmountOrBlank" === validateRoles[i]){  //validAmount 必须为正数金额或为空
			oneResult = validAmountOrBlank(elementValue, objectValidation);
		}
		else if ("natural" === validateRoles[i]){ //natural 必须为正整数
			oneResult = validateNatural(elementValue, objectValidation);
		}
		else if ("naturalOrBlank" === validateRoles[i]){ //natural 必须为正整数或为空
			oneResult = validateNaturalOrBlank(elementValue, objectValidation);
		}
		else if ("naturalNoZero" === validateRoles[i]){ //naturalNoZero 必须为不包括0的正整数
			oneResult = validateNaturalNoZero(elementValue, objectValidation);
		}	
		else if ("naturalNoZeroOrBlank" === validateRoles[i]){ //naturalNoZero 必须为不包括0的正整数或为空
			oneResult = validateNaturalNoZeroOrBlank(elementValue, objectValidation);
		}
		else if ("validIP" === validateRoles[i]){ //validIP must contain a valid IP
			oneResult = validateValidIP(elementValue, objectValidation);
		}	
		else if ("validBase64" === validateRoles[i]){ //validBase64 must contain a base64 string
			oneResult = validateValidBase64(elementValue, objectValidation);
		}				
		else if (validateRoles[i].indexOf("range") >= 0){ //range 范围应在[%s]之间
			oneResult = validateRange(elementValue, validateRoles[i], objectValidation);
		}	
		else if (validateRoles[i].indexOf("requiredDepend") >= 0){ //requiredDepend %s不为空时%s不能为空
			oneResult = validateRequiredDepend(elementValue, validateRoles[i], dataTableElements, objectValidation);
		}																																
		
		if (oneResult !== null && oneResult !== ''){
			validationResults.push(oneResult);
		}
	}
	return validationResults;
}

function validateRequired(elementValue, objectValidation){
	if (elementValue === null || elementValue === ''){
		return objectValidation.displayAttributeName + "不能为空.";
	}
	return null;
}

function validateMaxLength(elementValue, oneValidateRole, objectValidation){
	if (elementValue === null || elementValue === ''){
		return null;
	}
	else {
		var checkLength = getNumberFromValidateRole(oneValidateRole);
		if (elementValue.length > checkLength){
			return objectValidation.displayAttributeName + "长度不能超过" + checkLength + "位.";
		}
	}
	return null;
}

function validateMinLength(elementValue, oneValidateRole, objectValidation){
	if (elementValue === null || elementValue === ''){
		return null;
	}
	else {
		var checkLength = getNumberFromValidateRole(oneValidateRole);
		if (elementValue.length < checkLength){
			return objectValidation.displayAttributeName + "长度不能小于" + checkLength + "位.";
		}
	}
	return null;	
}

function validateMatches(elementValue, oneValidateRole, objectValidation){
	if (elementValue === null || elementValue === ''){
		return null;
	}
	else {
		var checkValues = getStringFromValidateRole(oneValidateRole);
		checkValues = "," + checkValues + ",";
		elementValue = "," + elementValue + ",";
		
		if (checkValues.indexOf("elementValue") < 0){
			return objectValidation.displayAttributeName + "与有效内容定义不匹配.";
		}
	}
	
	return null;
}

function validateMatchValue(elementValue, oneValidateRole, objectValidation){
	if (elementValue === null || elementValue === ''){
		return null;
	}
	else {
		var checkValue = getStringFromValidateRole(oneValidateRole);
		
		if (checkValue !== elementValue){
			return objectValidation.displayAttributeName + "与有效值定义不匹配.";
		}		
	}	

	return null;
}

function validateDefault(elementValue, objectValidation){
	if (elementValue === null || elementValue === ''){
		return null;
	}
	else {
		if (elementValue === "-1"){
			return objectValidation.displayAttributeName + "仍为缺省值, 请修改.";
		}		
	}	

	return null;	
}

function validateValidEmail(elementValue, objectValidation){
	var emailRegex = /^[a-zA-Z0-9.!#$%&amp;'*+\-\/=?\^_`{|}~\-]+@[a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)*$/;
	if (!emailRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为有效电子邮件地址.";
	}
	return null;	
}

function validateValidEmails(elementValue, objectValidation){
	var emailRegex = /^[a-zA-Z0-9.!#$%&amp;'*+\-\/=?\^_`{|}~\-]+@[a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)*$/;
	var emails = elementValue.split(",");

	for (var i in emails) {
		if (!emailRegex.test(emails[i])) {
			return objectValidation.displayAttributeName + "必须为有效电子邮件地址.";
		}
	}

	return null;	
}

function validateValidDate(elementValue, objectValidation){
	var dateRegex = /^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/;
	if (!dateRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为有效的日期.";
	}	

	return null;	
}

function validDateOrBlank(elementValue, objectValidation){
	var dateRegex = /^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/;
	if ((!dateRegex.test(elementValue)) && (elementValue !== null && elementValue !== '')){
		return objectValidation.displayAttributeName + "不为空时必须为有效的日期.";
	}	

	return null;	
}

function validateExactLength(elementValue, oneValidateRole, objectValidation){
	if (elementValue === null || elementValue === ''){
		return null;
	}
	else {
		var checkLength = getNumberFromValidateRole(oneValidateRole);
		
		if (elementValue.length !== checkLength){
			return objectValidation.displayAttributeName + "长度必须为" + checkLength + "位.";
		}
	}	

	return null;
}

function validateGreaterThan(elementValue, oneValidateRole, objectValidation){
	if (elementValue === null || elementValue === ''){
		return null;
	}
	else {
		var checkValue = getStringFromValidateRole(oneValidateRole);
		
		if (parseFloat(elementValue) < parseFloat(checkValue)){
			return objectValidation.displayAttributeName + "必须大于" + checkValue + ".";
		}		
	}

	return null;
}

function validateLessThan(elementValue, oneValidateRole, objectValidation){
	if (elementValue === null || elementValue === ''){
		return null;
	}
	else {
		var checkValue = getStringFromValidateRole(oneValidateRole);
		
		if (parseFloat(elementValue) < parseFloat(checkValue)){
			return objectValidation.displayAttributeName + "必须小于" + checkValue + ".";
		}		
	}	

	return null;
}

function validateAlpha(elementValue, objectValidation){
	var alphaRegex = /^[a-z]+$/i;
	if (!alphaRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为英文字符.";
	}	

	return null;	
}

function validateAlphaOrBlank(elementValue, objectValidation){
	var alphaRegex = /^[a-z]+$/i;
	if ((!alphaRegex.test(elementValue)) && (elementValue !== null && elementValue !== '')){
		return objectValidation.displayAttributeName + "不为空时必须为英文字符.";
	}	

	return null;	
}

function validateAlphaNumeric(elementValue, objectValidation){
	var alphaNumericRegex = /^[a-z0-9]+$/i;
	if (!alphaNumericRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为英文字符与数字.";
	}	

	return null;	
}

function validateAlphaNumericOrBlank(elementValue, objectValidation){
	var alphaNumericRegex = /^[a-z0-9]+$/i;
	if ((!alphaNumericRegex.test(elementValue)) && (elementValue !== null && elementValue !== '')){
		return objectValidation.displayAttributeName + "不为空时必须为英文字符与数字.";
	}	

	return null;	
}

function validateAlphaDash(elementValue, objectValidation){
	var alphaDashRegex = /^[a-z0-9_\-]+$/i;
	if (!alphaDashRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为英文字符,中划线或下划线.";
	}	

	return null;	
}

function validateAlphaDashOrBlank(elementValue, objectValidation){
	var alphaDashRegex = /^[a-z0-9_\-]+$/i;
	if ((!alphaDashRegex.test(elementValue)) && (elementValue !== null && elementValue !== '')){
		return objectValidation.displayAttributeName + "不为空时必须为英文字符,中划线或下划线.";
	}	

	return null;	
}

function validateNumeric(elementValue, objectValidation){
	var numericRegex = /^[0-9]+$/;
	if (!numericRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为数字.";
	}	

	return null;	
}

function validateNumericOrBlank(elementValue, objectValidation){
	var numericRegex = /^[0-9]+$/;
	if ((!numericRegex.test(elementValue)) && (elementValue !== null && elementValue !== '')){
		return objectValidation.displayAttributeName + "不为空时必须为数字.";
	}	

	return null;	
}

function validateInteger(elementValue, objectValidation){
	var integerRegex = /^\-?[0-9]+$/;
	if (!integerRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为整数.";
	}	

	return null;	
}

function validateIntegerOrBlank(elementValue, objectValidation){
	var integerRegex = /^\-?[0-9]+$/;
	if ((!integerRegex.test(elementValue)) && (elementValue !== null && elementValue !== '')){
		return objectValidation.displayAttributeName + "不为空时必须为整数.";
	}	

	return null;	
}

function validateDecimal(elementValue, objectValidation){
	var decimalRegex = /^-?[0-9]*\.?[0-9]+$/;
	if (!decimalRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为数值.";
	}	

	return null;	
}

function validateDecimalOrBlank(elementValue, objectValidation){
	var decimalRegex = /^-?[0-9]*\.?[0-9]+$/;
	if ((!decimalRegex.test(elementValue)) && elementValue !== null && elementValue !== ''){
		return objectValidation.displayAttributeName + "不为空时必须为数值.";
	}	
	
	return null;	
}

function validAmount(elementValue, objectValidation){
	var amountRegex = /^-?[0-9]*(\.\d{2})?$/;
	if (!amountRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为金额.";
	}	

	return null;	
}

function validAmountOrBlank(elementValue, objectValidation){
	var amountRegex = /^-?[0-9]*(\.\d{2})?$/;
	if ((!amountRegex.test(elementValue)) && (elementValue !== null && elementValue !== '')){
		return objectValidation.displayAttributeName + "不为空时必须为金额.";
	}	

	return null;	
}

function validateNatural(elementValue, objectValidation){
	var naturalRegex = /^[0-9]+$/i;
	if (!naturalRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为正整数.";
	}	

	return null;	
}

function validateNaturalOrBlank(elementValue, objectValidation){
	var naturalRegex = /^[0-9]+$/i;
	if ((!naturalRegex.test(elementValue)) && (elementValue !== null && elementValue !== '')){
		return objectValidation.displayAttributeName + "不为空时必须为正整数.";
	}	

	return null;	
}

function validateNaturalNoZero(elementValue, objectValidation){
	var naturalNoZeroRegex = /^[1-9][0-9]*$/i;
	if (!naturalNoZeroRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为不包括0的正整数.";
	}	

	return null;	
}

function validateNaturalNoZeroOrBlank(elementValue, objectValidation){
	var naturalNoZeroRegex = /^[1-9][0-9]*$/i;
	if ((!naturalNoZeroRegex.test(elementValue)) && (elementValue !== null && elementValue !== '')){
		return objectValidation.displayAttributeName + "不为空时必须为不包括0的正整数.";
	}	

	return null;	
}

function validateValidIP(elementValue, objectValidation){
	var ipRegex = /^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})$/i;
	if (!ipRegex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为有效的IP地址.";
	}	

	return null;	
}

function validateValidBase64(elementValue, objectValidation){
	var base64Regex = /[^a-zA-Z0-9\/\+=]/i;
	if (!base64Regex.test(elementValue)){
		return objectValidation.displayAttributeName + "必须为有效的Base64值.";
	}	

	return null;	
}

function validateRange(elementValue, oneValidateRole, objectValidation){
	if (elementValue === null || elementValue === ''){
		return null;
	}
	else {
		var checkValue = getStringFromValidateRole(oneValidateRole);
		var checkValues = checkValue.split(",");

		if (parseFloat(elementValue) < parseFloat(checkValues[0]) || parseFloat(elementValue) > parseFloat(checkValues[1])){
			return objectValidation.displayAttributeName + "范围应在" + checkValue + "之间.";
		}	
	}	

	return null;	
}

function validateRequiredDepend(elementValue, oneValidateRole, dataTableElements, objectValidation){
	var elementDepend = getElementFromDataTableElements(dataTableElements, wantId);
	var elementDependValue = elementDepend.val();
	if (elementDependValue !== null && elementDependValue !== ''){
		if (elementValue === null || elementValue === ''){
			var displayAttributeName = getDisplayAttributeNameFromObjectValidations(wantId, objectValidations);
			return displayAttributeName + "不为空时" + objectValidation.displayAttributeName + "不能为空.";
		}
	}
	
	return null;
}

function getNumberFromValidateRole(oneValidateRole){
	return parseInt(getStringFromValidateRole(oneValidateRole));
}

function getStringFromValidateRole(oneValidateRole){
	var valueInString =  oneValidateRole.substring(oneValidateRole.indexOf("[") + 1, oneValidateRole.indexOf("]"));
	return valueInString;
}

function getElementFromDataTableElements(dataTableElements, wantId){
	for (var i=0; i < dataTableElements.length -1; ++i){
		if ($(dataTableElements[i]).children().length > 0 && $(dataTableElements[i]).children().first().is(":input")){
			if ($(dataTableElements[i]).children().first().attr("id") !== undefined){
				currentId = $(dataTableElements[i]).children().first().attr("id");
				if (typeof currentId !== typeof undefined && currentId !== false){
					if (currentId === "entity_" + wantId || currentId === wantId){
						return dataTableElements[i];								
					}
				}							
			}		
		}
	}
}

function getDisplayAttributeNameFromObjectValidations(attributeName, objectValidations){
	for (var i in objectValidations){
		if (attributeName === objectValidations[i].attributeName){		
			return objectValidations[i].displayAttributeName;									
		}
	}	
}
			
function getObjectValidations(data){
	var objectValidations = new Array();
	$.each($.parseJSON(data), function() {
		//console.log(this.elementCSSType);
		var objectValidation = {
			"attributeName" : this.attributeName,
			"displayAttributeName" : this.displayAttributeName,
			"displayActionType" : this.displayActionType,
			"verificationRole" : this.verificationRole
		};
		objectValidations.push(objectValidation);				        
	});
				
	return objectValidations;					
}			