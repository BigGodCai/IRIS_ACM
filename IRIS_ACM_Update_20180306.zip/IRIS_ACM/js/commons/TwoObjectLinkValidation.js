function doTwoObjectLinkValidate(actionName){
//	var dataPara = getFormJson("#dataForm");
	$.ajax({
		cache : true,
		type : "POST",
		async: false,
		url: actionName+'!twoObjectsLinkValidation',
		data:$('#dataForm').serialize(),
		dataType:"json",//设置需要返回的数据类型
		success:doCheckValidateResult,
		error:function(request, status, error){
	   	var SELECTOR_ERRORS = $("#messageBox");
			SELECTOR_ERRORS.empty();
			SELECTOR_ERRORS.append(request.responseText);
			SELECTOR_ERRORS.fadeIn(200);
		}//这里不要加","
	});	
}

function getFormJson(frm) {
    var o = {};
    var a = $(frm).serializeArray();
    $.each(a, function () {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });

    return o;
}