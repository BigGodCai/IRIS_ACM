			function removeDisable(){
				var orgFormElements = $('#dataTable tr td');
				for (var i=0; i < orgFormElements.length -1; ++i){
					if ($(orgFormElements[i]).children(":first").is('select')) {
						$(orgFormElements[i]).children(":first").removeAttr("disabled");
					}
				}
			}
			
			function doUIMasking(pageNameValue){
				var isEditRecordValue = $('#isEditRecord').val();
				var dataValues = {//设置数据源
						pageName : pageNameValue,
						isEditRecord : isEditRecordValue
					};
				
				$.ajax({
					type: "post",
					async: false,
					cache: false,
					timeout: 30000,						
					url: "uiMaskAction",
					data: dataValues,
					dataType:"json",//设置需要返回的数据类型
					success:callbackDisplayUI,
					error:function(request, status, error){
						//alert(request.responseText);
				    	var SELECTOR_ERRORS = $("#messageBox");
				        SELECTOR_ERRORS.empty();
				        SELECTOR_ERRORS.append(request.responseText);
				        SELECTOR_ERRORS.fadeIn(200);
						//alert("系统异常，请稍后重试！");
					}//这里不要加","
				});
				var actiontype=document.getElementsByName("entity.actiontype");
				if(actiontype!=undefined&&actiontype[0]!=undefined&&actiontype[0].value=='A'){
					document.getElementsByName("entity.actiondesc")[0].readOnly=true;
				}
				isApprovedEachDisAbleTrue();
			}
			
			function callbackDisplayUI(data){			
				var SELECTOR_ERRORS = $("#messageBox");
				SELECTOR_ERRORS.hide();
				
				var uiResources = getUIResource(data);
				if ($.isEmptyObject(uiResources)){
					return;
				}			
				
				var orgFormElements = $('#dataTable tr td');


								
				var dataTable = $('#dataTable');
				var trElement = $('#dataTable tr:eq(0)').clone();
				var lastTR = $('#dataTable tr').last();
				var currentTR = trElement.clone();
				trElement.children().remove();
				$('#dataTable tr').remove();
				var iCount = 0;
				var currentId;
				for (var i=0; i < orgFormElements.length -1; ++i){
					if (isInputElement(orgFormElements[i]) === true){
						if ($(orgFormElements[i]).children().first().attr("id") !== undefined){
							currentId = $(orgFormElements[i]).children().first().attr("id");
							if (typeof currentId !== typeof undefined && currentId !== false){
								for (var j in uiResources){
									if (currentId === "entity_" + uiResources[j].elementID || currentId === uiResources[j].elementID){
										if (iCount === 0){
											currentTR = trElement.clone();
											dataTable.append(currentTR);
										}
										
										//for wholeRow
										if (uiResources[j].displayFormatType !== "wholeRow"){
											iCount = iCount + 2;
										}
										else {
											if (iCount === 2){ //当前行已经包含了一个td元素, 需要另起1行
												currentTR = trElement.clone();
												dataTable.append(currentTR);
											}
											
											iCount = 4;
										}
										
										//console.log($(orgFormElements[i-1]));
										
										currentTR = getCurrentTR(currentTR, orgFormElements[i-1], orgFormElements[i], uiResources[j]);
										//currentTR.append($(orgFormElements[i-1]));
										//currentTR.append($(orgFormElements[i]));
										if (iCount === 4){
											iCount = 0;
										}								
									}
								}
							}							
						}
					}
				}
				dataTable.append(lastTR);
			}
			
			function getCurrentTR(currentTR, orgFormElementLabelTD, orgFormElementInputTD, uiResource){
				$(orgFormElementLabelTD).removeClass("required");

				if (uiResource.elementCSSType === "required"){
					$(orgFormElementLabelTD).addClass("required");
				}
				currentTR.append($(orgFormElementLabelTD));
				
				$(orgFormElementInputTD).children(":first").removeAttr("readonly");
				if (uiResource.displayActionType === "readonly"){
					if ($(orgFormElementInputTD).children(":first").is('select')) { //select box需要使用disabled属性
						$(orgFormElementInputTD).children(":first").attr("disabled","disabled");
					}
					else if ($(orgFormElementInputTD).children(":first").is('div')) { //struts:StrutsDatePicker需要使用readonly=true属性
						$(orgFormElementInputTD).children().first().attr('disabled','disabled');
					}					
					else { //$(orgFormElementInputTD).children(":first").is('input')
						$(orgFormElementInputTD).children(":first").attr("readonly", "readonly");
					}
				}
				currentTR.append($(orgFormElementInputTD));
				return currentTR;
			}
			
			function getUIResource(data){
				var uiResources = new Array();
				//var jsonString = "[{\"id\":47,\"elementID\":\"branchCode\"},{\"id\":48,\"elementID\":\"subBranchCode\"}]";
				$.each($.parseJSON(data), function() {
			        //console.log(this.elementCSSType);
					var uiResource = {
							"elementID" : this.elementID,
							"elementCSSType" : this.elementCSSType,
							"displayActionType" : this.displayActionType,
							"displayFormatType" : this.displayFormatType
					};
					uiResources.push(uiResource);				        
				});
				
				return uiResources;					
			}			