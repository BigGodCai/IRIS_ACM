function isInputElement(element){
	return true;
	
	if ($(element).children().length > 0){
		if ($(element).children().first().is(":input")){
			return true;
		} 
		else if (typeof( $(element).children().first().attr('dojoType') ) != 'undefined' 
			|| $(element).children().first().html().indexOf('dojo') > -1 ){
			return true;
		}  
	}
	return false;
}	

function isApprovedEachDisAbleTrue(){
	var isEditRecord = document.getElementsByName("isEditRecord");
	var isApproveds=document.getElementsByName("entity.isApproved");
	if((isApproveds!=undefined&&isApproveds[0]!=undefined&&isApproveds[0].value=="true")||
			(isEditRecord!=undefined&&isEditRecord[0]!=undefined&&isEditRecord[0].value=='2')){
		var dataTableElements = $('#dataTable tr td');
		for (var i=0; i < dataTableElements.length -1; ++i){
			$(dataTableElements[i]).children(":first").removeAttr("disabled");
			$(dataTableElements[i]).children(":first").attr("disabled","disabled");
		}
	}
}