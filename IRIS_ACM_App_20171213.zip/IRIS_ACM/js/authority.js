function authorityButton(pageName){
	var systemButtonGrantedList = $("#systemButtonGranted").val();
	if(systemButtonGrantedList == undefined){
		return;
	}
	//编辑
	var editRightName = pageName + ".edit";
	if (systemButtonGrantedList.indexOf(editRightName) < 0){
		var buttonNames=document.getElementsByName("editButtonDIV");
		hiddenButtonByNames(buttonNames);
	}
	
	//增加
	var addRightName = pageName + ".add";
	if (systemButtonGrantedList.indexOf(addRightName) < 0){
		$("#addButtonDIV").hide();
	}
	
	//审核
	var approveRightName = pageName + ".approve";
	if (systemButtonGrantedList.indexOf(approveRightName) < 0){
		$("#approveButtonDIV").hide();
	}
	
	//取消审核
	var unApproveRightName = pageName + ".unApprove";
	if (systemButtonGrantedList.indexOf(unApproveRightName) < 0){
		$("#unApproveButtonDIV").hide();
	}
	
	//全部审核
	var allApproveRightName= pageName+".allApprove";
	if (systemButtonGrantedList.indexOf(allApproveRightName) < 0){
		$("#allApproveButtonDIV").hide();
	}
	
	//删除
	var deleteRightName = pageName + ".delete";
	if (systemButtonGrantedList.indexOf(deleteRightName) < 0){
		var buttonNames=document.getElementsByName("deleteButtonDIV");
		hiddenButtonByNames(buttonNames);
	}
	
	//下载
	var downloadRightName= pageName+".download";
	if (systemButtonGrantedList.indexOf(downloadRightName) < 0){
		$("#downloadButtonDIV").hide();
	}
	
	//上传
	var uploadRightName=pageName+".upload";
	if (systemButtonGrantedList.indexOf(uploadRightName) < 0){
		$("#uploadButtonDIV").hide();
	}
	
	//数据提取
	var dataimportRightName=pageName+".dataimport";
	if (systemButtonGrantedList.indexOf(dataimportRightName) < 0){
		$("#dataimportButtonDIV").hide();
	}
	
	//校验
	var validateRightName=pageName+".validate";
	if (systemButtonGrantedList.indexOf(validateRightName) < 0){
		$("#validateButtonDIV").hide();
	}
	
	//导出
	var exportRightName=pageName+".export";
	if (systemButtonGrantedList.indexOf(exportRightName) < 0){
		$("#exportButtonDIV").hide();
	}
	
	//导出PDF
	var exportRightName=pageName+".exportPDF";
	if (systemButtonGrantedList.indexOf(exportRightName) < 0){
		$("#exportPDFButtonDIV").hide();
	}

	//导入
	var importRightName=pageName+".import";
	if (systemButtonGrantedList.indexOf(importRightName) < 0){
		$("#importButtonDIV").hide();
	}
	
	//汇总
	var combineRightName=pageName+".combine";
	if (systemButtonGrantedList.indexOf(combineRightName) < 0){
		$("#combineButtonDIV").hide();
	}
	
	//检查审核
	var checkRightName=pageName+".check";
	if (systemButtonGrantedList.indexOf(checkRightName) < 0){
		$("#checkButtonDIV").hide();
	}
	
	//读取反馈
	var readRightName=pageName+".read";
	if (systemButtonGrantedList.indexOf(readRightName) < 0){
		$("#readButtonDIV").hide();
	}
	
	//发送MTS
	var sendRightName=pageName+".send";
	if (systemButtonGrantedList.indexOf(sendRightName) < 0){
		$("#sendButtonDIV").hide();
	}
	
	//生成PDF
	var generatePDFRightName=pageName+".generatePDF";
	if (systemButtonGrantedList.indexOf(generatePDFRightName) < 0){
		$("#generatePDFButtonDIV").hide();
	}
	
	//发票打印
	var taxInvoicePrintRightName=pageName+".taxInvoicePrint";
	if (systemButtonGrantedList.indexOf(taxInvoicePrintRightName) < 0){
		$("#taxInvoicePrintButtonDIV").hide();
	}
	
	//发票下载
	var taxInvoiceDownloadRightName=pageName+".taxInvoiceDownload";
	if (systemButtonGrantedList.indexOf(taxInvoiceDownloadRightName) < 0){
		$("#taxInvoiceDownloadButtonDIV").hide();
	}

	//发票批量下载
	var taxInvoiceDownloadRightName=pageName+".taxInvoiceBatchDownload";
	if (systemButtonGrantedList.indexOf(taxInvoiceDownloadRightName) < 0){
		$("#taxInvoiceBatchDownloadButtonDIV").hide();
	}
	
	//部分批量下载
	var taxInvoiceDownloadRightName=pageName+".taxInvoiceBatchPartDownload";
	if (systemButtonGrantedList.indexOf(taxInvoiceDownloadRightName) < 0){
		$("#taxInvoiceBatchPartDownloadButtonDIV").hide();
	}
	
	//手工生成发票
	var taxInvoiceDownloadRightName=pageName+".createTaxInvoiceByHand";
	if (systemButtonGrantedList.indexOf(taxInvoiceDownloadRightName) < 0){
		$("#createTaxInvoiceByHandButtonDIV").hide();
	}
	
	//特殊客户认定
	var specialCustomerRightName=pageName+".checkSpecialCustomer";
	if (systemButtonGrantedList.indexOf(specialCustomerRightName) < 0){
		$("#checkSpecialCustomerButtonDIV").hide();
	}
	
	//汇总标记
	var specialCustomerRightName=pageName+".chooseIsCombineTinvoiceIds";
	if (systemButtonGrantedList.indexOf(specialCustomerRightName) < 0){
		$("#chooseIsCombineTinvoiceIdsButtonDIV").hide();
	}
	
	//清除汇总标记
	var specialCustomerRightName=pageName+".clearIsCombineTinvoiceIds";
	if (systemButtonGrantedList.indexOf(specialCustomerRightName) < 0){
		$("#clearIsCombineTinvoiceIdsButtonDIV").hide();
	}
	
	
	//反假币  增加
	var acm_goToAdd=pageName+".goToAdd";
	if (systemButtonGrantedList.indexOf(acm_goToAdd) < 0){
		$("#goToAddDIV").hide();
	}
	//反假币  审核
	var acm_approveDIV=pageName+".approveDIV";
	if (systemButtonGrantedList.indexOf(acm_approveDIV) < 0){
		$("#approveDIV").hide();
	}
	//反假币  取消审核
	var acm_unApproveDIV=pageName+".unApproveDIV";
	if (systemButtonGrantedList.indexOf(acm_unApproveDIV) < 0){
		$("#unApproveDIV").hide();
	}
	//反假币  全部审核
	var acm_allApproveDIV=pageName+".allApproveDIV";
	if (systemButtonGrantedList.indexOf(acm_allApproveDIV) < 0){
		$("#allApproveDIV").hide();
	}
	//反假币  生成比对文件
	var acm_generateCompareFileDIV=pageName+".generateCompareFileDIV";
	if (systemButtonGrantedList.indexOf(acm_generateCompareFileDIV) < 0){
		$("#generateCompareFileDIV").hide();
	}
	//反假币  下载
	var acm_downloadDIV=pageName+".downloadDIV";
	if (systemButtonGrantedList.indexOf(acm_downloadDIV) < 0){
		$("#downloadDIV").hide();
	}
	//反假币  编辑
	//var acm_editDiv=pageName+".editDIV";
	//if (systemButtonGrantedList.indexOf(acm_editDiv) < 0){
		
	//	var inps = document.getElementById("editDIV");
	     
	//    for(var i = 0,inp; inp = inps[i++];){
	//            inp.value = '111111111';
	//    }
	//    var div_span = $("div.pretty medium default btn2");
	//    for( var i = 0; i < div_span.length; i++ ) {
	//         div_span[i].style.visibility='hidden';
	         //div_span.[i].style.display="none";
	//     }
	
		//$("div.pretty medium default btn2").hide();
	//}
	//反假币  删除
	//var acm_deleteDiv=pageName+".deleteDIV";
	//if (systemButtonGrantedList.indexOf(acm_deleteDiv) < 0){
	//	$("#deleteDIV").hide();
	//}
	
}

	function hiddenButtonByNames(buttonNames){
		for(var i=0;i<buttonNames.length;i++){
			buttonNames[i].style.visibility='hidden';
		}
	}


function authorityMenu(){
	var systemMenuGranted = $("#systemMenuGranted").val();
	var systemMenuGrantedList=systemMenuGranted.split("||");
	for(var i=0;i<systemMenuGrantedList.length;i++){
		var menuid="#"+systemMenuGrantedList[i];
		$(menuid).hide();
	}
}