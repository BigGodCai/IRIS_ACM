function showErrorMessage(errors) {
	var SELECTOR_ERRORS = $("#messageBox");
	if (errors.length > 0) {
        SELECTOR_ERRORS.empty();
        for (var i = 0, errorLength = errors.length; i < errorLength; i++) {
            SELECTOR_ERRORS.append(errors[i].message + '<br />');
        }
        
        SELECTOR_ERRORS.fadeIn(200);
    } 
    else {
        SELECTOR_ERRORS.hide();
        return true;
    }
}
