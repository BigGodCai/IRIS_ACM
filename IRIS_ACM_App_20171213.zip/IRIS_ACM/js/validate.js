/*
 * validate.js 1.4
 * Copyright (c) 2011 - 2014 Rick Harrison, http://rickharrison.me
 * validate.js is open sourced under the MIT license.
 * Portions of validate.js are inspired by CodeIgniter.
 * http://rickharrison.github.com/validate.js
 */

(function(window, document, undefined) {
	/*
	 * If you would like an application-wide config, change these defaults.
	 * Otherwise, use the setMessage() function to configure form specific
	 * messages.
	 */

	var defaults = {
		messages : {
			required : '%s不能为空.',
			matches : '%s与字段有效内容定义不匹配.',
			matchValue : '%s与定义的内容与%s不匹配.',
			"default" : '%s仍为缺省值, 请修改 .',
			valid_email : '%s必须为有效电子邮件地址 .',
			valid_emails : '%s必须为有效电子邮件地址 .',
			valid_date : '%s此日期格式应为YYYYMMDD,或日期范围有误.',
			min_length : '%s内容过短%s.',
			max_length : '%s内容过长%s.',
			exact_length : '%s必须为规定长度%s.',
			greater_than : '%s必须大于%s.',
			less_than : '%s必须小于%s.',
			alpha : '%s的内容必须为英文字符.',
			alpha_numeric : '%s的内容必须为英文字符与数字.',
			alpha_dash : '%s的内容必须为英文字符, 数字, 中划线或下划线 .',
			numeric : '%s内容必须为数字.',
			integer : '%s必须为整数.',
			decimal : '%s必须为数值且大于等于0.',
			valid_amount : '%s必须为大于等于0的最多两位小数的数字.',
			is_natural : '%s必须为正整数.',
			is_natural_no_zero : '%s必须为不包括0的正整数.',
			valid_ip : 'The %s field must contain a valid IP.',
			valid_base64 : 'The %s field must contain a base64 string.',
			valid_credit_card : 'The %s field must contain a valid credit card number.',
			is_file_type : 'The %s field must contain only %s files.',
			valid_url : 'The %s field must contain a valid URL.',
			check : '%s和%s二者至少填写一个.',
			range : '%s范围应在[%s]之间.',
			required_depend : '%s不能为空.'
		},
		callback : function(errors) {

		}
	};

	/*
	 * Define the regular expressions that will be used
	 */

	var ruleRegex = /^(.+?)\[(.+)\]$/, numericRegex = /^[0-9]+$/, integerRegex = /^\-?[0-9]+$/, decimalRegex = /^[0-9]*\.?[0-9]+$/, emailRegex = /^[a-zA-Z0-9.!#$%&amp;'*+\-\/=?\^_`{|}~\-]+@[a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)*$/, alphaRegex = /^[a-z]+$/i, alphaNumericRegex = /^[a-z0-9]+$/i, alphaDashRegex = /^[a-z0-9_\-]+$/i, naturalRegex = /^[0-9]+$/i, naturalNoZeroRegex = /^[1-9][0-9]*$/i, ipRegex = /^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})$/i, base64Regex = /[^a-zA-Z0-9\/\+=]/i, numericDashRegex = /^[\d\-\s]+$/, urlRegex = /^((http|https):\/\/(\w+:{0,1}\w*@)?(\S+)|)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?$/,
	/* chris add */
	amountRegex = /^(([1-9]\d*)|0)(\.\d{2})?$/, valid_dateRegex = /^(([0-9]{3}[1-9]|[0-9]{2}[1-9][0-9]{1}|[0-9]{1}[1-9][0-9]{2}|[1-9][0-9]{3})(((0[13578]|1[02])(0[1-9]|[12][0-9]|3[01]))|((0[469]|11)(0[1-9]|[12][0-9]|30))|(02(0[1-9]|1[0-9]|2[0-8]))))|((([0-9]{2})(0[48]|[2468][048]|[13579[26]))|((0[48]|[2468][048]|[13579][26])00)0229)$/;

	/*
	 * The exposed public object to validate a form:
	 * 
	 * @param formNameOrNode - String - The name attribute of the form (i.e.
	 * <form name="myForm"></form>) or node of the form element @param fields -
	 * Array - [{ name: The name of the element (i.e. <input name="myField" />)
	 * display: 'Field Name' rules: required|matches[password_confirm] }] @param
	 * callback - Function - The callback after validation has been performed.
	 * @argument errors - An array of validation errors @argument event - The
	 * javascript event
	 */

	var FormValidator = function(formNameOrNode, fields, callback) {
		this.callback = callback || defaults.callback;
		this.errors = [];
		this.fields = {};
		this.form = this._formByNameOrNode(formNameOrNode) || {};
		this.messages = {};
		this.handlers = {};
		this.conditionals = {};

		for ( var i = 0, fieldLength = fields.length; i < fieldLength; i++) {
			var field = fields[i];

			// If passed in incorrectly, we need to skip the field.
			if ((!field.name && !field.names) || !field.rules) {
				continue;
			}

			/*
			 * Build the master fields array that has all the information needed
			 * to validate
			 */

			if (field.names) {
				for ( var j = 0, fieldNamesLength = field.names.length; j < fieldNamesLength; j++) {
					this._addField(field, field.names[j]);
				}
			} else {
				this._addField(field, field.name);
			}
		}

		/*
		 * Attach an event callback for the form submission
		 */

		var _onsubmit = this.form.onsubmit;

		this.form.onsubmit = (function(that) {
			return function(evt) {
				try {
					return that._validateForm(evt)
							&& (_onsubmit === undefined || _onsubmit());
				} catch (e) {
				}
			};
		})(this);
		
		/*var _onclick = this.form.onclick;

		this.form.onclick = (function(that) {
			return function(evt) {
				try {
					return that._validateForm(evt)
							&& (_onclick === undefined || _onclick());
				} catch (e) {
				}
			};
		})(this);*/
		
	},

	attributeValue = function(element, attributeName) {
		var i;

		if ((element.length > 0)
				&& (element[0].type === 'radio' || element[0].type === 'checkbox')) {
			for (i = 0, elementLength = element.length; i < elementLength; i++) {
				if (element[i].checked) {
					return element[i][attributeName];
				}
			}

			return;
		}

		return element[attributeName];
	};

	/*
	 * @public Sets a custom message for one of the rules
	 */

	FormValidator.prototype.setMessage = function(rule, message) {
		this.messages[rule] = message;

		// return this for chaining
		return this;
	};

	/*
	 * @public Registers a callback for a custom rule (i.e.
	 * callback_username_check)
	 */

	FormValidator.prototype.registerCallback = function(name, handler) {
		if (name && typeof name === 'string' && handler
				&& typeof handler === 'function') {
			this.handlers[name] = handler;
		}

		// return this for chaining
		return this;
	};

	/*
	 * @public Registers a conditional for a custom 'depends' rule
	 */

	FormValidator.prototype.registerConditional = function(name, conditional) {
		if (name && typeof name === 'string' && conditional
				&& typeof conditional === 'function') {
			this.conditionals[name] = conditional;
		}

		// return this for chaining
		return this;
	};

	/*
	 * @private Determines if a form dom node was passed in or just a string
	 * representing the form name
	 */

	FormValidator.prototype._formByNameOrNode = function(formNameOrNode) {
		return (typeof formNameOrNode === 'object') ? formNameOrNode
				: document.forms[formNameOrNode];
	};

	/*
	 * @private Adds a file to the master fields array
	 */

	FormValidator.prototype._addField = function(field, nameValue) {
		this.fields[nameValue] = {
			name : nameValue,
			display : field.display || nameValue,
			rules : field.rules,
			depends : field.depends,
			id : null,
			type : null,
			value : null,
			checked : null
		};
	};

	/*
	 * @private Runs the validation when the form is submitted.
	 */

	FormValidator.prototype._validateForm = function(evt) {
		this.errors = [];

		for ( var key in this.fields) {
			if (this.fields.hasOwnProperty(key)) {
				var field = this.fields[key] || {}, element = this.form[field.name];

				if (element && element !== undefined) {
					field.id = attributeValue(element, 'id');
					field.type = (element.length > 0) ? element[0].type
							: element.type;
					field.value = attributeValue(element, 'value');
					field.checked = attributeValue(element, 'checked');

					/*
					 * Run through the rules for each field. If the field has a
					 * depends conditional, only validate the field if it passes
					 * the custom function
					 */

					if (field.depends && typeof field.depends === "function") {
						if (field.depends.call(this, field)) {
							this._validateField(field);
						}
					} else if (field.depends
							&& typeof field.depends === "string"
							&& this.conditionals[field.depends]) {
						if (this.conditionals[field.depends].call(this, field)) {
							this._validateField(field);
						}
					} else {
						this._validateField(field);
					}
				}
			}
		}

		if (typeof this.callback === 'function') {
			this.callback(this.errors, evt);
		}

		if (this.errors.length > 0) {
			if (evt && evt.preventDefault) {
				evt.preventDefault();
			} else if (event) {
				// IE uses the global event variable
				event.returnValue = false;
			}
		}

		return true;
	};

	/*
	 * @private Looks at the fields value and evaluates it against the given
	 * rules
	 */

	FormValidator.prototype._validateField = function(field) {
		var rules = field.rules.split('|'), indexOfRequired = field.rules
				.indexOf('required'), isEmpty = (!field.value
				|| field.value === '' || field.value === undefined);

		/*
		 * Run through the rules and execute the validation methods as needed
		 */

		for ( var i = 0, ruleLength = rules.length; i < ruleLength; i++) {
			var method = rules[i], param = null, failed = false, parts = ruleRegex
					.exec(method);

			/*
			 * If this field is not required and the value is empty, continue on
			 * to the next rule unless it's a callback. This ensures that a
			 * callback will always be called but other rules will be skipped.
			 */

			if (indexOfRequired === -1 && method.indexOf('!callback_') === -1
					&& isEmpty && method.indexOf('check') === -1) {
				continue;
			}

			/*
			 * If the rule has a parameter (i.e. matches[param]) split it out
			 */

			if (parts) {
				method = parts[1];
				param = parts[2];
			}

			if (method.charAt(0) === '!') {
				method = method.substring(1, method.length);
			}

			/*
			 * If the hook is defined, run it to find any validation errors
			 */

			if (typeof this._hooks[method] === 'function') {
				if (!this._hooks[method].apply(this, [ field, param ])) {
					failed = true;
				}
			} else if (method.substring(0, 9) === 'callback_') {
				// Custom method. Execute the handler if it was registered
				method = method.substring(9, method.length);

				if (typeof this.handlers[method] === 'function') {
					if (this.handlers[method].apply(this,
							[ field.value, param ]) === false) {
						failed = true;
					}
				}
			}

			/*
			 * If the hook failed, add a message to the errors array
			 */

			if (failed) {
				// Make sure we have a message for this rule
				var source = this.messages[field.name + '.' + method]
						|| this.messages[method] || defaults.messages[method], message = 'An error has occurred with the '
						+ field.display + ' field.';

				if (source) {
					message = source.replace('%s', field.display);

					if (param) {
						message = message
								.replace(
										'%s',
										(this.fields[param]) ? this.fields[param].display
												: param);
					}
				}

				this.errors.push({
					id : field.id,
					name : field.name,
					message : message,
					rule : method
				});

				// Break out so as to not spam with validation errors (i.e.
				// required and valid_email)
				break;
			}
		}
	};

	/*
	 * @private Object containing all of the validation hooks
	 */

	FormValidator.prototype._hooks = {
		required : function(field) {
			var value = field.value;

			if ((field.type === 'checkbox') || (field.type === 'radio')) {
				return (field.checked === true);
			}

			return (value !== null && value !== '');
		},

		"default" : function(field, defaultName) {
			return field.value !== defaultName;
		},

		matches : function(field, matchName) {
			var el = this.form[matchName];

			if (el) {
				return field.value === el.value;
			}

			return false;
		},

		valid_email : function(field) {
			return emailRegex.test(field.value);
		},

		valid_emails : function(field) {
			var result = field.value.split(",");

			for ( var i = 0, resultLength = result.length; i < resultLength; i++) {
				if (!emailRegex.test(result[i])) {
					return false;
				}
			}

			return true;
		},

		min_length : function(field, length) {
			if (!numericRegex.test(length)) {
				return false;
			}

			return (field.value.length >= parseInt(length, 10));
		},

		max_length : function(field, length) {
			if (!numericRegex.test(length)) {
				return false;
			}

			return (field.value.length <= parseInt(length, 10));
		},

		exact_length : function(field, length) {
			if (!numericRegex.test(length)) {
				return false;
			}

			return (field.value.length === parseInt(length, 10));
		},

		greater_than : function(field, param) {
			if (!decimalRegex.test(field.value)) {
				return false;
			}

			return (parseFloat(field.value) > parseFloat(param));
		},

		less_than : function(field, param) {
			if (!decimalRegex.test(field.value)) {
				return false;
			}

			return (parseFloat(field.value) < parseFloat(param));
		},

		alpha : function(field) {
			return (alphaRegex.test(field.value));
		},

		alpha_numeric : function(field) {
			return (alphaNumericRegex.test(field.value));
		},

		alpha_dash : function(field) {
			return (alphaDashRegex.test(field.value));
		},

		numeric : function(field) {
			return (numericRegex.test(field.value));
		},

		integer : function(field) {
			return (integerRegex.test(field.value));
		},

		decimal : function(field) {
			if(field.value !== ""){
				return (decimalRegex.test(field.value));
			}
			return true;
		},

		is_natural : function(field) {
			return (naturalRegex.test(field.value));
		},

		is_natural_no_zero : function(field) {
			return (naturalNoZeroRegex.test(field.value));
		},

		valid_ip : function(field) {
			return (ipRegex.test(field.value));
		},

		valid_base64 : function(field) {
			return (base64Regex.test(field.value));
		},

		valid_url : function(field) {
			return (urlRegex.test(field.value));
		},

		valid_credit_card : function(field) {
			// Luhn Check Code from https://gist.github.com/4075533
			// accept only digits, dashes or spaces
			if (!numericDashRegex.test(field.value))
				return false;

			// The Luhn Algorithm. It's so pretty.
			var nCheck = 0, nDigit = 0, bEven = false;
			var strippedField = field.value.replace(/\D/g, "");

			for ( var n = strippedField.length - 1; n >= 0; n--) {
				var cDigit = strippedField.charAt(n);
				nDigit = parseInt(cDigit, 10);
				if (bEven) {
					if ((nDigit *= 2) > 9)
						nDigit -= 9;
				}

				nCheck += nDigit;
				bEven = !bEven;
			}

			return (nCheck % 10) === 0;
		},

		is_file_type : function(field, type) {
			if (field.type !== 'file') {
				return true;
			}

			var ext = field.value.substr((field.value.lastIndexOf('.') + 1)), typeArray = type
					.split(','), inArray = false, i = 0, len = typeArray.length;

			for (i; i < len; i++) {
				if (ext == typeArray[i])
					inArray = true;
			}

			return inArray;
		},

		valid_amount : function(field) {
			return (amountRegex.test(field.value));
		},

		valid_date : function(field, params) {
			var flag = true;
			// 获得当前日期的YYYYMMDD格式 的字符串
			var now = (new Date((new Date()).setDate((new Date()).getDate())))
					.getFullYear()
					+ ''
					+ ((new Date((new Date()).setDate((new Date()).getDate()))
							.getMonth() + 1) <= 9 ? ('0' + (new Date(
							(new Date()).setDate((new Date()).getDate()))
							.getMonth() + 1)) : (new Date((new Date())
							.setDate((new Date()).getDate())).getMonth() + 1))
					+ ''
					+ ((new Date((new Date()).setDate((new Date()).getDate())))
							.getDate() <= 9 ? ('0' + (new Date((new Date())
							.setDate((new Date()).getDate()))).getDate())
							: (new Date((new Date()).setDate((new Date())
									.getDate()))).getDate());
			if (params) {
				if (params.indexOf(",") === -1) {
					var el = this.form[params];
					if (el && field.value < el.value) {
						flag = false;
					}
				} else {
					if (params === ",") {
						if (field.value > now) {
							flag = false;
						}
					} else {
						var param = params.split(",");
						if (param[0]) {
							var el = this.form[param[0]];
							if (el && field.value < el.value) {
								flag = false;
							}
						}

						if (param[1]) {
							var el = this.form[param[1]];
							if (el && field.value > el.value) {
								flag = false;
							}
						}

					}

				}
			}

			return (valid_dateRegex.test(field.value) && flag);
		},

		check : function(field, param) {
			var flag = true;
			if (param) {
				var el = this.form[param];
				if (field.value === "" && el.value === "") {
					flag = false;
				}
			}
			return flag;
		},

		range : function(field, params) {
			var param = params.split(",");
			if(field.value !== ""){
				return (field.value >= param[0] && field.value <= param[1]);
			}
			return true;

		},

		matchValue : function(field, param) {
			if (param.indexOf("≠") !== -1) {
				var value = param.substring(1);
				return field.value !== value;
			} else
				return filed.value === value;
		},
		//
		required_depend : function(field, param) {
			if (param) {
				var el = this.form[param];
				if (el.length > 1) {
					if (el[0].type === 'radio' && el[0].checked) {
						return field.value !== "";
					} else 
						return true;
				} else {
					if (el.value !== "") {
						return field.value !== "";
					} else
						return true;
				}
			}
		}

	};

	window.FormValidator = FormValidator;

})(window, document);
